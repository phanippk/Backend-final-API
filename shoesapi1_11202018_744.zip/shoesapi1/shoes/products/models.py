from django.db import models

CATEGORY_CHOICES = (('man','Man'), ('woman',"Woman"), ('kids','Kids'),)


class Product(models.Model):
    created = models.DateTimeField(auto_now_add=True)
    title = models.CharField(max_length=100, blank=True, default='')
    details = models.TextField(blank=False)
    price = models.IntegerField(blank=False, default=0)
    category = models.CharField(choices=CATEGORY_CHOICES, default='Man', max_length=100)

    class Meta:
        ordering = ('created',)

    def __str__(self):
        return self.title
