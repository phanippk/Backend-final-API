from django.contrib import admin
from .models import Checkout
# Register your models here.


class CheckoutAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "user", "price", "category", "quantity",)
    list_filter = ("category", "created", "name",)


admin.site.register(Checkout, CheckoutAdmin)
