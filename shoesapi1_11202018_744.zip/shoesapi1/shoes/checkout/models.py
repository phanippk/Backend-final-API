from django.db import models


class Checkout(models.Model):
    created = models.DateTimeField(auto_now_add=True)
    name = models.CharField(max_length=100, blank=True, default='')
    user = models.TextField(blank=False)
    price = models.IntegerField(blank=False, default=0)
    category = models.CharField(default=None, max_length=100)
    quantity = models.IntegerField(blank=False, default=0)

    class Meta:
        ordering = ('created',)

    def __str__(self):
        return self.name

